package cool.structures.symbol;

import cool.structures.Scope;

public class Declarations {
    public static boolean Err;
    public static Scope globals;
    public static String objectType = "Object";
    public static String stringType = "String";
    public static String intType = "Int";
    public static String selfType = "SELF_TYPE";
    public static String self = "self";
}
