package cool.structures.symbol;

import cool.structures.Symbol;

public class SelfSymbol extends Symbol {
    public SelfSymbol(String name) {
        super(name);
    }
}
